package com.ws.msbank.entities;

public enum AccountType {
    CURRENT,SAVING;
}
