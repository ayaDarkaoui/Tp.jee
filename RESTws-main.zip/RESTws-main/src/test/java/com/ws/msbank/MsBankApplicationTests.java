package com.ws.msbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
